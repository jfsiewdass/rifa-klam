<!--begin::Global Javascript Bundle(mandatory for all pages)-->
<script src="{{ asset((env('APP_ENV') === 'production' ? 'public/' : '') .'Keen_files/plugins.bundle.js') }}"></script>
<script src="{{ asset((env('APP_ENV') === 'production' ? 'public/' : '') .'Keen_files/scripts.bundle.js') }}"></script>
<!--end::Global Javascript Bundle-->
