@extends('layouts.auth')

@section('content')
@endsection